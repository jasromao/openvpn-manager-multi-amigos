from flask import Flask, render_template, request, send_file, redirect, url_for
from flask_httpauth import HTTPBasicAuth
import subprocess
import os
import configparser
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

SERVIDORES_CONF = "/home/ubuntu/openvpn-manager-multi/servidores.conf"
EASYRSA_VALIDADE_DIAS = "7300"  # 20 anos

def carregar_servidores():
    config = configparser.ConfigParser()
    config.read(SERVIDORES_CONF)
    return config

def validade_certificado(caminho):
    """Devolve a data de validade e o estado de um certificado X.509."""
    if not caminho or not os.path.isfile(caminho):
        return {"data": "-", "dias": None, "estado": "indisponivel"}

    resultado = subprocess.run(
        ["openssl", "x509", "-in", caminho, "-noout", "-enddate"],
        capture_output=True,
        text=True,
    )

    if resultado.returncode != 0 or "=" not in resultado.stdout:
        return {"data": "-", "dias": None, "estado": "indisponivel"}

    try:
        valor = resultado.stdout.strip().split("=", 1)[1].strip()
        fim = parsedate_to_datetime(valor)
        if fim.tzinfo is None:
            fim = fim.replace(tzinfo=timezone.utc)
        dias = (fim.astimezone(timezone.utc).date() - datetime.now(timezone.utc).date()).days
    except (TypeError, ValueError, IndexError):
        return {"data": "-", "dias": None, "estado": "indisponivel"}

    if dias < 0:
        estado = "expirado"
    elif dias <= 90:
        estado = "critico"
    elif dias <= 365:
        estado = "aviso"
    else:
        estado = "ok"

    return {
        "data": fim.astimezone(timezone.utc).strftime("%d/%m/%Y"),
        "dias": dias,
        "estado": estado,
    }

def caminho_certificado_servidor(servidor, dados):
    """Localiza o certificado realmente usado pelo servidor OpenVPN."""
    easyrsa_dir = dados.get("EASYRSA_DIR", "")
    candidato = f"{easyrsa_dir}/pki/issued/{servidor}.crt"
    if os.path.isfile(candidato):
        return candidato

    server_conf = dados.get("SERVER_CONF", "")
    if server_conf and os.path.isfile(server_conf):
        try:
            with open(server_conf, encoding="utf-8", errors="replace") as ficheiro:
                for linha in ficheiro:
                    linha = linha.strip()
                    if linha.startswith("cert "):
                        partes = linha.split(None, 1)
                        if len(partes) == 2:
                            return partes[1].strip()
        except OSError:
            pass

    return candidato

app = Flask(__name__)
auth = HTTPBasicAuth()

USERS = {
    "admin": "admin1234"
}

@auth.verify_password
def verify_password(username, password):
    return USERS.get(username) == password

@app.route("/")
@auth.login_required
def index():
    config = carregar_servidores()
    servidores = []

    for secao in config.sections():
        dados = config[secao]
        easyrsa_dir = dados.get("EASYRSA_DIR", "")
        servidores.append({
            "id": secao,
            "nome": dados.get("NOME", secao),
            "porta": dados.get("PORTA", ""),
            "vpn": dados.get("VPN_PREFIX", ""),
            "ativo": dados.get("ATIVO", "1"),
            "validade_servidor": validade_certificado(caminho_certificado_servidor(secao, dados)),
            "validade_ca": validade_certificado(f"{easyrsa_dir}/pki/ca.crt")
        })

    status = "OFFLINE"

    for secao in config.sections():
        if config[secao].get("ATIVO", "1") != "1":
            continue

        servico = f"openvpn-server@{secao}"
        resultado = subprocess.run(
            ["systemctl", "is-active", servico],
            capture_output=True,
            text=True
        ).stdout.strip()

        if resultado == "active":
            status = "ONLINE"
            break

    return render_template(
        "index.html",
        status=status,
        servidores=servidores
    )
@app.route("/servidor/<servidor_id>")
@auth.login_required
def selecionar_servidor(servidor_id):
    config = carregar_servidores()

    if servidor_id not in config.sections():
        return "Servidor não encontrado", 404

    return redirect(url_for("clientes", servidor=servidor_id))

@app.route("/clientes")
@auth.login_required
def clientes_todos():
    config = carregar_servidores()
    todos = []

    for servidor in config.sections():
        dados = config[servidor]

        easyrsa_dir = dados.get("EASYRSA_DIR")
        ccd_dir = dados.get("CCD_DIR")
        service = dados.get("SERVICE")

        if not easyrsa_dir or not ccd_dir or not service:
            continue

        instancia = service.split("@", 1)[1]

        pasta = f"{easyrsa_dir}/pki/issued"
        status_log = f"/run/openvpn-server/{instancia}-status.log"

        online = {}

        if os.path.exists(status_log):
            online_text = subprocess.run(
                ["sudo", "cat", status_log],
                capture_output=True,
                text=True
            ).stdout

            for linha in online_text.splitlines():
                if linha.startswith("CLIENT_LIST"):
                    partes = linha.split()
                    if len(partes) >= 4:
                        online[partes[1]] = partes[3]

        if not os.path.isdir(pasta):
            continue

        for f in os.listdir(pasta):
            if not f.endswith(".crt"):
                continue

            if f in ("server.crt", f"{servidor}.crt"):
                continue

            nome = f[:-4]
            estado = "ONLINE" if nome in online else "OFFLINE"
            ipvpn = online.get(nome, "-")
            rede = "-"

            ccd = f"{ccd_dir}/{nome}"

            if os.path.exists(ccd):
                redes = []

                with open(ccd) as ficheiro:
                    for linha in ficheiro:
                        linha = linha.strip()

                        if linha.startswith("ifconfig-push "):
                            partes = linha.split()
                            if len(partes) >= 2:
                                ipvpn = partes[1]

                        if linha.startswith("# rede_local="):
                            redes.append(linha.split("=", 1)[1].strip())

                        elif linha.startswith("iroute "):
                            partes = linha.split()
                            if len(partes) >= 2:
                                redes.append(partes[1])

                if redes:
                    rede = ", ".join(dict.fromkeys(redes))

            todos.append({
                "servidor": servidor,
                "nome": nome,
                "estado": estado,
                "ipvpn": ipvpn,
                "rede": rede,
                "validade": validade_certificado(f"{pasta}/{f}"),
            })

    return render_template(
        "clientes_todos.html",
        clientes=sorted(
            todos,
            key=lambda x: (x["servidor"].lower(), x["nome"].lower())
        )
    )

@app.route("/clientes/<servidor>")
@auth.login_required
def clientes(servidor):
    config = carregar_servidores()

    if servidor not in config.sections():
        return "Servidor não encontrado", 404

    dados = config[servidor]
    nome_servidor = dados.get("NOME", servidor)

    easyrsa_dir = dados.get("EASYRSA_DIR")
    ccd_dir = dados.get("CCD_DIR")
    service = dados.get("SERVICE")

    instancia = service.split("@", 1)[1]

    pasta = f"{easyrsa_dir}/pki/issued"
    status_log = f"/run/openvpn-server/{instancia}-status.log"

    online = {}
    lista = []

    online_text = subprocess.run(
        ["sudo", "cat", status_log],
        capture_output=True,
        text=True
    ).stdout

    for linha in online_text.splitlines():
        if linha.startswith("CLIENT_LIST"):
            partes = linha.split()
            if len(partes) >= 4:
                online[partes[1]] = partes[3]

    for f in os.listdir(pasta):
        if not f.endswith(".crt") or f in ("server.crt", f"{servidor}.crt"):
            continue

        nome = f[:-4]

        estado = "ONLINE" if nome in online else "OFFLINE"
        ipvpn = online.get(nome, "-")

        rede = "-"

        ccd = f"{ccd_dir}/{nome}"
        if os.path.exists(ccd):
            redes = []

            with open(ccd) as ficheiro:
                for linha in ficheiro:
                    linha = linha.strip()

                    if linha.startswith("ifconfig-push "):
                       partes = linha.split()
                       if len(partes) >= 2:
                           ipvpn = partes[1]

                    if linha.startswith("# rede_local="):
                        redes.append(linha.split("=",1)[1].strip())

                    elif linha.startswith("iroute"):
                        partes = linha.split()
                        if len(partes) >= 2:
                            redes.append(partes[1])

            if redes:
                rede = ", ".join(redes)

        lista.append({
            "nome": nome,
            "estado": estado,
            "ipvpn": ipvpn,
            "rede": rede,
            "validade": validade_certificado(f"{pasta}/{f}")
        })

    return render_template(
        "clientes.html",
        clientes=sorted(lista, key=lambda x: x["nome"].lower()),
        servidor=servidor,
        nome_servidor=nome_servidor
    )


from flask import request

@app.route("/criar", methods=["GET", "POST"])
@app.route("/criar/<servidor>", methods=["GET", "POST"])
@auth.login_required
def criar(servidor=None):
    if servidor is None:
        servidor = "servidor1"

    if request.method == "POST":
        nome = request.form["nome"]
        tipo = request.form["tipo"]

        if tipo == "casa":
            rede = request.form["rede_casa"]
            subprocess.run([
                "sudo",
                "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
                servidor,
                nome,
                tipo,
                rede
            ])

        elif tipo == "fora":
            subprocess.run([
                "sudo",
                "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
                servidor,
                nome,
                tipo
            ])

        elif tipo == "glinet":
            redes = request.form["redes"]
            subprocess.run([
                "sudo",
                "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
                servidor,
                nome,
                tipo,
                redes
            ])

        return f"Cliente {nome} criado com sucesso.<br><br><a href='/clientes/{servidor}'>Ver clientes</a>"

    return render_template("criar.html")

@app.route("/download/<cliente>/<tipo>")
@auth.login_required
def download(cliente, tipo):
    import os

    if tipo == "vpn":
        ficheiro = f"/home/ubuntu/{cliente}.ovpn"
    elif tipo == "vps":
        ficheiro = f"/home/ubuntu/{cliente}-vps.ovpn"
    else:
        return "Tipo invÃƒÆ’Ã‚Â¡lido", 404

    if not os.path.exists(ficheiro):
        return "Ficheiro nÃƒÆ’Ã‚Â£o encontrado", 404

    return send_file(ficheiro, as_attachment=True)

@app.route("/apagar/<servidor>/<cliente>", methods=["POST"])
@auth.login_required
def apagar_cliente(servidor, cliente):
    subprocess.run(
        [
            "sudo",
            "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
            servidor,
            "remover",
            cliente,
        ],
        check=True,
    )
    return redirect(url_for("clientes", servidor=servidor))

@app.route("/editar-cliente/<servidor>/<cliente>", methods=["GET", "POST"])
@auth.login_required
def editar_cliente(servidor, cliente):
    config = carregar_servidores()

    if servidor not in config.sections():
        return "Servidor não encontrado", 404

    dados = config[servidor]
    easyrsa_dir = dados.get("EASYRSA_DIR", "")
    ccd_dir = dados.get("CCD_DIR", "")

    cert = f"{easyrsa_dir}/pki/issued/{cliente}.crt"
    ccd = f"{ccd_dir}/{cliente}"

    if not os.path.isfile(cert):
        return "Cliente não encontrado", 404

    tipo_atual = "fora"
    rede_casa = ""
    redes_glinet = []
    ip_virtual = ""

    if os.path.isfile(ccd):
        with open(ccd, encoding="utf-8", errors="replace") as ficheiro:
            for linha in ficheiro:
                linha = linha.strip()

                if linha.startswith("# tipo="):
                    tipo_ccd = linha.split("=", 1)[1].strip()
                    if tipo_ccd == "pc_casa":
                        tipo_atual = "casa"
                    elif tipo_ccd == "pc_fora":
                        tipo_atual = "fora"
                    elif tipo_ccd == "glinet":
                        tipo_atual = "glinet"

                elif linha.startswith("# rede_local="):
                    rede_casa = linha.split("=", 1)[1].strip()

                elif linha.startswith("ifconfig-push "):
                    partes = linha.split()
                    if len(partes) >= 2:
                        ip_virtual = partes[1]

                elif linha.startswith("iroute "):
                    partes = linha.split()
                    if len(partes) >= 2:
                        redes_glinet.append(partes[1])

    if request.method == "POST":
        tipo = request.form.get("tipo", "").strip()
        ip_virtual_novo = request.form.get("ip_virtual", "").strip()

        if tipo == "casa":
            redes = request.form.get("rede_casa", "").strip()
        elif tipo == "glinet":
            redes_raw = request.form.get("redes", "")
            redes_raw = redes_raw.replace("\r", "\n").replace(",", "\n").replace(";", "\n")
            redes = ",".join(
                parte.strip()
                for parte in redes_raw.splitlines()
                if parte.strip()
            )
        elif tipo == "fora":
            redes = ""
        else:
            return "Tipo de cliente inválido", 400

        resultado = subprocess.run(
            [
                "sudo",
                "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
                servidor,
                "editar",
                cliente,
                tipo,
                redes,
                ip_virtual_novo,
            ],
            capture_output=True,
            text=True,
        )

        if resultado.returncode != 0:
            erro = (resultado.stderr or resultado.stdout or "Erro desconhecido").strip()
            return f"Erro ao editar cliente: {erro}", 400

        return redirect(url_for("clientes", servidor=servidor))

    return render_template(
        "editar_cliente.html",
        servidor=servidor,
        cliente=cliente,
        tipo=tipo_atual,
        rede_casa=rede_casa,
        redes="\n".join(redes_glinet),
        ip_virtual=ip_virtual,
    )


@app.route("/renovar/<servidor>/<cliente>", methods=["POST"])
@auth.login_required
def renovar_cliente(servidor, cliente):
    config = carregar_servidores()

    if servidor not in config.sections():
        return "Servidor não encontrado", 404

    resultado = subprocess.run(
        [
            "sudo",
            "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
            servidor,
            "renovar",
            cliente,
        ],
        capture_output=True,
        text=True,
    )

    if resultado.returncode != 0:
        erro = (resultado.stderr or resultado.stdout or "Erro desconhecido").strip()
        return f"Erro ao renovar .ovpn: {erro}", 400

    return redirect(url_for("clientes", servidor=servidor))


@app.route("/servidores")
@auth.login_required
def servidores():
    config = carregar_servidores()
    lista = []

    for secao in config.sections():
        dados = config[secao]
        easyrsa_dir = dados.get("EASYRSA_DIR", "")
        lista.append({
            "id": secao,
            "nome": dados.get("NOME", secao),
            "porta": dados.get("PORTA", ""),
            "vpn": dados.get("VPN_PREFIX", ""),
            "ativo": dados.get("ATIVO", "1"),
            "validade_servidor": validade_certificado(caminho_certificado_servidor(secao, dados)),
            "validade_ca": validade_certificado(f"{easyrsa_dir}/pki/ca.crt")
        })

    return render_template("servidores.html", servidores=lista)

@app.route("/servidores/editar/<servidor_id>", methods=["GET", "POST"])
@auth.login_required
def editar_servidor(servidor_id):
    config = carregar_servidores()

    if servidor_id not in config.sections():
        return "Servidor não encontrado", 404

    dados = config[servidor_id]
    nome = dados.get("NOME", servidor_id)
    remote_host_atual = dados.get("REMOTE_HOST", "").strip()
    remote_conf = dados.get("REMOTE_CONFIG", "").strip()

    if request.method == "POST":
        novo_remote_host = request.form.get("remote_host", "").strip()

        if not novo_remote_host:
            return "IP/DDNS não pode ficar vazio", 400

        if any(c.isspace() for c in novo_remote_host):
            return "IP/DDNS inválido: não pode conter espaços", 400

        antigo_remote_host = remote_host_atual
        antigo_remote_conf = None

        if remote_conf and os.path.isfile(remote_conf):
            with open(remote_conf, encoding="utf-8", errors="replace") as ficheiro:
                antigo_remote_conf = ficheiro.read()

        config[servidor_id]["REMOTE_HOST"] = novo_remote_host

        with open(SERVIDORES_CONF, "w") as ficheiro:
            config.write(ficheiro)

        if remote_conf:
            os.makedirs(os.path.dirname(remote_conf), exist_ok=True)
            with open(remote_conf, "w") as ficheiro:
                ficheiro.write(novo_remote_host + "\n")

        resultado = subprocess.run(
            [
                "sudo",
                "/home/ubuntu/openvpn-manager-multi/criar-cliente-ovpn-web",
                servidor_id,
                "renovar-todos",
            ],
            capture_output=True,
            text=True,
        )

        if resultado.returncode != 0:
            # Se a regeneração falhar, repõe o endereço anterior.
            config = carregar_servidores()
            if servidor_id in config.sections():
                config[servidor_id]["REMOTE_HOST"] = antigo_remote_host
                with open(SERVIDORES_CONF, "w") as ficheiro:
                    config.write(ficheiro)

            if remote_conf:
                if antigo_remote_conf is None:
                    try:
                        os.remove(remote_conf)
                    except FileNotFoundError:
                        pass
                else:
                    with open(remote_conf, "w") as ficheiro:
                        ficheiro.write(antigo_remote_conf)

            erro = (resultado.stderr or resultado.stdout or "Erro desconhecido").strip()
            return f"Erro ao atualizar os .ovpn: {erro}", 500

        return redirect(url_for("servidores"))

    return render_template(
        "editar_servidor.html",
        servidor=servidor_id,
        nome=nome,
        remote_host=remote_host_atual,
    )

@app.route("/servidores/apagar/<servidor_id>", methods=["POST"])
@auth.login_required
def apagar_servidor(servidor_id):
    config = carregar_servidores()

    if servidor_id not in config.sections():
        return "Servidor não encontrado", 404

    dados = config[servidor_id]

    vpn_prefix = dados.get("VPN_PREFIX", "")
    easy_rsa = dados.get("EASYRSA_DIR", "")
    server_conf = dados.get("SERVER_CONF", "")
    ccd_dir = dados.get("CCD_DIR", "")
    service = dados.get("SERVICE", f"openvpn-server@{servidor_id}")
    remote_conf = dados.get("REMOTE_CONFIG", "")

    # Parar e desativar o servidor
    subprocess.run(
        ["sudo", "systemctl", "stop", service],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    subprocess.run(
        ["sudo", "systemctl", "disable", service],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    # Apagar ficheiros .ovpn dos clientes deste servidor
    issued_dir = f"{easy_rsa}/pki/issued"

    if os.path.isdir(issued_dir):
        for ficheiro in os.listdir(issued_dir):
            if ficheiro.endswith(".crt"):
                cliente = ficheiro[:-4]

                if cliente != servidor_id:
                    subprocess.run(
                        ["sudo", "rm", "-f",
                         f"/home/ubuntu/{cliente}.ovpn",
                         f"/home/ubuntu/{cliente}-vps.ovpn"]
                    )

    # Apagar configuração, PKI e CCD
    for caminho in [easy_rsa, ccd_dir]:
        if caminho:
            subprocess.run(["sudo", "rm", "-rf", caminho])

    for caminho in [server_conf, remote_conf]:
        if caminho:
            subprocess.run(["sudo", "rm", "-f", caminho])

    # Apagar regras de rede deste servidor
    if vpn_prefix:
        rede_vpn = f"{vpn_prefix}.0/24"

        while subprocess.run(
            [
                "sudo", "iptables", "-t", "nat", "-C", "POSTROUTING",
                "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        ).returncode == 0:
            subprocess.run(
                [
                    "sudo", "iptables", "-t", "nat", "-D", "POSTROUTING",
                    "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
                ]
            )

        subprocess.run(
            ["sudo", "iptables", "-D", "FORWARD",
             "-s", rede_vpn, "-j", "ACCEPT"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        subprocess.run(
            ["sudo", "iptables", "-D", "FORWARD",
             "-d", rede_vpn, "-m", "conntrack",
             "--ctstate", "RELATED,ESTABLISHED", "-j", "ACCEPT"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

            # Apagar regras de isolamento deste servidor
        tun_apagar = f"tun-{servidor_id}"

        for outro in config.sections():
            if outro == servidor_id:
                continue

            tun_outro = f"tun-{outro}"

            while subprocess.run(
                [
                    "sudo", "iptables", "-C", "FORWARD",
                    "-i", tun_apagar,
                    "-o", tun_outro,
                    "-j", "DROP"
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            ).returncode == 0:
                subprocess.run(
                    [
                        "sudo", "iptables", "-D", "FORWARD",
                        "-i", tun_apagar,
                        "-o", tun_outro,
                        "-j", "DROP"
                    ],
                    check=True
                )

            while subprocess.run(
                [
                    "sudo", "iptables", "-C", "FORWARD",
                    "-i", tun_outro,
                    "-o", tun_apagar,
                    "-j", "DROP"
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            ).returncode == 0:
                subprocess.run(
                    [
                        "sudo", "iptables", "-D", "FORWARD",
                        "-i", tun_outro,
                        "-o", tun_apagar,
                        "-j", "DROP"
                    ],
                    check=True
                ) 

    # Retirar do servidores.conf
    config.remove_section(servidor_id)

    with open(SERVIDORES_CONF, "w") as ficheiro:
        config.write(ficheiro)

    # Guardar regras iptables
    subprocess.run(
        ["sudo", "netfilter-persistent", "save"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    return redirect(url_for("servidores"))

@app.route("/servidores/adicionar", methods=["GET", "POST"])
@auth.login_required
def adicionar_servidor():
    if request.method == "POST":
        nome = request.form["nome"].strip()
        porta = request.form["porta"].strip()
        vpn_prefix = request.form["vpn_prefix"].strip()
        remote_host = request.form["remote_host"].strip()

        config = carregar_servidores()

        numero = 1
        while f"servidor{numero}" in config.sections():
            numero += 1

        secao = f"servidor{numero}"

        easyrsa_dir = f"/etc/openvpn/{secao}-easy-rsa"
        pki_dir = f"{easyrsa_dir}/pki"
        ccd_dir = f"/etc/openvpn/ccd-{secao}"
        server_conf = f"/etc/openvpn/server/{secao}.conf"
        remote_conf = f"/etc/openvpn/remote-host-{secao}.conf"

        try:
            # Criar estrutura Easy-RSA nova
            subprocess.run(
                ["sudo", "mkdir", "-p", easyrsa_dir],
                check=True
            )

            subprocess.run(
                [
                    "sudo", "cp",
                    "/usr/share/easy-rsa/easyrsa",
                    easyrsa_dir + "/easyrsa"
                ],
                check=True
            )

            subprocess.run(
                ["sudo", "chmod", "+x", easyrsa_dir + "/easyrsa"],
                check=True
            )

            # Criar PKI nova
            subprocess.run(
                [
                    "sudo",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "init-pki"
                ],
                check=True
            )

            # Criar CA automática com validade fixa de 20 anos.
            subprocess.run(
                [
                    "sudo", "env",
                    "EASYRSA_BATCH=1",
                    f"EASYRSA_REQ_CN={secao}-CA",
                    f"EASYRSA_CA_EXPIRE={EASYRSA_VALIDADE_DIAS}",
                    f"EASYRSA_CERT_EXPIRE={EASYRSA_VALIDADE_DIAS}",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "build-ca",
                    "nopass"
                ],
                check=True
            )

            # Criar certificado do servidor com validade fixa de 20 anos.
            subprocess.run(
                [
                    "sudo", "env",
                    f"EASYRSA_CERT_EXPIRE={EASYRSA_VALIDADE_DIAS}",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "--batch",
                    "build-server-full",
                    secao,
                    "nopass"
                ],
                check=True,
            )

            # DH
            subprocess.run(
                [
                    "sudo",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "gen-dh"
                ],
                check=True
            )

            # CRL com validade fixa de 20 anos, para não ficar com o prazo padrão curto.
            subprocess.run(
                [
                    "sudo", "env",
                    f"EASYRSA_CRL_DAYS={EASYRSA_VALIDADE_DIAS}",
                    easyrsa_dir + "/easyrsa",
                    f"--pki-dir={pki_dir}",
                    "gen-crl"
                ],
                check=True
            )

            # TLS key
            subprocess.run(
                [
                    "sudo", "openvpn",
                    "--genkey", "secret",
                    f"{pki_dir}/ta.key"
                ],
                check=True
            )

            # CCD próprio
            subprocess.run(
                ["sudo", "mkdir", "-p", ccd_dir],
                check=True
            )

            # Criar configuração OpenVPN
            conteudo = f"""port {porta}
proto udp
dev tun-{secao}

topology subnet
server {vpn_prefix}.0 255.255.255.0

ca {pki_dir}/ca.crt
cert {pki_dir}/issued/{secao}.crt
key {pki_dir}/private/{secao}.key
dh {pki_dir}/dh.pem
tls-crypt {pki_dir}/ta.key

verify-client-cert require
remote-cert-tls client
tls-version-min 1.2

data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305
data-ciphers-fallback AES-256-GCM
auth SHA256

client-to-client
keepalive 10 120
persist-key
persist-tun

user nobody
group nogroup

status /run/openvpn-server/{secao}-status.log
status-version 3
verb 3
explicit-exit-notify 1
client-config-dir {ccd_dir}
crl-verify {pki_dir}/crl.pem
"""

            subprocess.run(
                ["sudo", "tee", server_conf],
                input=conteudo,
                text=True,
                stdout=subprocess.DEVNULL,
                check=True
            )

            # Criar ficheiro remoto
            subprocess.run(
                ["sudo", "touch", remote_conf],
                check=True
            )

            # Ativar e arrancar automaticamente
            subprocess.run(
                ["sudo", "systemctl", "enable", f"openvpn-server@{secao}"],
                check=True
            )

            subprocess.run(
                ["sudo", "systemctl", "restart", f"openvpn-server@{secao}"],
                check=True
            )

            # Criar NAT para a rede VPN deste servidor
            rede_vpn = f"{vpn_prefix}.0/24"

            subprocess.run(
                 [
                    "sudo", "iptables", "-t", "nat", "-C", "POSTROUTING",
                    "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )

            if subprocess.run(
                [
                    "sudo", "iptables", "-t", "nat", "-C", "POSTROUTING",
                    "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            ).returncode != 0:
                subprocess.run(
                    [
                        "sudo", "iptables", "-t", "nat", "-A", "POSTROUTING",
                        "-s", rede_vpn, "-o", "ens3", "-j", "MASQUERADE"
                    ],
                    check=True
                )
                    # Isolar este servidor dos outros servidores OpenVPN
                tun_novo = f"tun-{secao}"
        
                for outro in config.sections():
                    tun_outro = f"tun-{outro}"
        
                    # Novo -> outro
                    if subprocess.run(
                        [
                            "sudo", "iptables", "-C", "FORWARD",
                            "-i", tun_novo,
                            "-o", tun_outro,
                            "-j", "DROP"
                        ],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    ).returncode != 0:
                        subprocess.run(
                            [
                                "sudo", "iptables", "-A", "FORWARD",
                                "-i", tun_novo,
                                "-o", tun_outro,
                                "-j", "DROP"
                            ],
                            check=True
                        )
        
                    # Outro -> novo
                    if subprocess.run(
                        [
                            "sudo", "iptables", "-C", "FORWARD",
                            "-i", tun_outro,
                            "-o", tun_novo,
                            "-j", "DROP"
                        ],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL
                    ).returncode != 0:
                        subprocess.run(
                            [
                                "sudo", "iptables", "-A", "FORWARD",
                                "-i", tun_outro,
                                "-o", tun_novo,
                                "-j", "DROP"
                            ],
                            check=True
                        )
        
            subprocess.run(
                ["sudo", "netfilter-persistent", "save"],
                check=True
            )

        except subprocess.CalledProcessError as e:
            return f"Erro ao criar {secao}: {e}", 500

        # Só grava no painel depois de tudo criado
        config[secao] = {
            "NOME": nome,
            "PORTA": porta,
            "VPN_PREFIX": vpn_prefix,
            "VPN_NETMASK": "255.255.255.0",
            "REMOTE_HOST": remote_host,
            "EASYRSA_DIR": easyrsa_dir,
            "SERVER_CONF": server_conf,
            "CCD_DIR": ccd_dir,
            "SERVICE": f"openvpn-server@{secao}",
            "REMOTE_CONFIG": remote_conf,
            "ATIVO": "1"
        }

        with open(SERVIDORES_CONF, "w") as ficheiro:
            config.write(ficheiro)

        return redirect(url_for("servidores"))

    return render_template("adicionar_servidor.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)

